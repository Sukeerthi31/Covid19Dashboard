from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.contrib.operators.snowflake_operator import SnowflakeOperator
#from plugins.operators.s3_to_snowflake_operator import S3ToSnowflakeTransferOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from datetime import datetime, timedelta
import os
import requests
from airflow.models import BaseOperator
from airflow.contrib.hooks.snowflake_hook import SnowflakeHook
from airflow.utils.decorators import apply_defaults


class S3ToSnowflakeTransferOperator(BaseOperator):
    """
    Executes an COPY command to load files from s3 to Snowflake
    :param s3_keys: reference to a list of S3 keys
    :type s3_keys: list
    :param table: reference to a specific table in snowflake database
    :type table: str
    :param s3_bucket: reference to a specific S3 bucket
    :type s3_bucket: str
    :param file_format: reference to a specific file format
    :type file_format: str
    :param schema: reference to a specific schema in snowflake database
    :type schema: str
    :param columns_array: reference to a specific columns array in snowflake database
    :type columns_array: list
    :param snowflake_conn_id: reference to a specific snowflake database
    :type snowflake_conn_id: str
    """
    template_fields = ('s3_keys',)
    

    @apply_defaults
    def __init__(self,
                 s3_keys,
                 table,
                 stage,
                 file_format,
                 schema,  # TODO: shouldn't be required, rely on session/user defaults
                 columns_array=None,
                 autocommit=True,
                 snowflake_conn_id='snowflake_default',
                 *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.s3_keys = s3_keys
        self.table = table
        self.stage = stage
        self.file_format = file_format
        self.schema = schema
        self.columns_array = columns_array
        self.autocommit = autocommit
        self.snowflake_conn_id = snowflake_conn_id

    def execute(self, context):
        snowflake_hook = SnowflakeHook(snowflake_conn_id=self.snowflake_conn_id)

        # Snowflake won't accept list of files it has to be tuple only.
        # but in python tuple([1]) = (1,) => which is invalid for snowflake
        files = str(self.s3_keys)
        files = files.replace('[', '(')
        files = files.replace(']', ')')

        # we can extend this based on stage
        base_sql = """
                    FROM @{stage}/
                    files={files}
                    file_format={file_format}
                """.format(
            stage=self.stage,
            files=files,
            file_format=self.file_format
        )

        if self.columns_array:
            copy_query = """
                COPY INTO {schema}.{table}({columns}) {base_sql}
            """.format(
                schema=self.schema,
                table=self.table,
                columns=",".join(self.columns_array),
                base_sql=base_sql
            )
        else:
            copy_query = """
                COPY INTO {schema}.{table} {base_sql}
            """.format(
                schema=self.schema,
                table=self.table,
                base_sql=base_sql
            )

        self.log.info('Executing COPY command...')
        print(snowflake_hook.get_uri())
        snowflake_hook.run(copy_query, self.autocommit)
        self.log.info("COPY command completed")
S3_CONN_ID = 'aws_bucket_loading'
BUCKET = 'covid-19-dataseta'
name = 'covid_data'  # swap your name here



def upload_to_s3():

    # Instanstiaute
    s3_hook = S3Hook(aws_conn_id=S3_CONN_ID)
    print("Created Connection")
    print(s3_hook.get_session())
    print(s3_hook)

    # Base URL
    url = 'https://covidtracking.com/api/v1/states/'

    res = requests.get('https://covidtracking.com/api/v1/states/current.csv')

    # Take string, upload to S3 using predefined method
    s3_hook.load_string(res.text, 'current.csv', bucket_name=BUCKET, replace=True)




# Default settings applied to all tasks
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': False,
    'email': ['varalikamahajan13@gmail.com'],
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}
# Using a DAG context manager, you don't have to specify the dag property of each task


with DAG('covid_data_s3_to_snowflake',
         start_date=datetime(2020, 6, 1),
         max_active_runs=3,
         # https://airflow.apache.org/docs/stable/scheduler.html#dag-runs
         schedule_interval='@daily',
         default_args=default_args,
         catchup=False
         ) as dag:

    t0 = DummyOperator(task_id='start')

    generate_files = PythonOperator(
            task_id='generate_file_current',  # task id is generated dynamically
            python_callable=upload_to_s3,
            op_kwargs={'endpoint': 'current'}
    )

    snowflake = S3ToSnowflakeTransferOperator(
            task_id='upload_current_snowflake',
            s3_keys=['current.csv'],
            stage='MY_CSV_STAGE',
            table='LIVECOVID19DATA',
            schema='public',
            file_format='mycsvformat',
            snowflake_conn_id='snowflake_conn'
        )

    t0 >> generate_files >> snowflake
