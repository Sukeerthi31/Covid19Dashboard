show stages;
show file formats;

USE DEMO_DB;

create or replace file format mycsvformat
  type = 'CSV'
  field_delimiter = ','
  skip_header = 1;
  
create or replace stage my_csv_stage
  file_format = mycsvformat
  url = 's3://covid-19-dataseta'
  credentials=(aws_key_id='AKIARQBOZ5ML7SIP4HGK' aws_secret_key='SCenkBRsOhl+xeATbHXL0GAqbshuGe3WU/HDxZbj');


create or replace table general(
NAME STRING,
AGE NUMBER);

copy into GENERAL
  from @my_csv_stage/Book1.csv
  on_error = 'skip_file';
  
Select * from GENERAL

