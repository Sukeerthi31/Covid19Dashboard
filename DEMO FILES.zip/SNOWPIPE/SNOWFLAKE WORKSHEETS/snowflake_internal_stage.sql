show stages;
show file formats;

USE demo_db;
create or replace file format mycsvformat
  type = 'CSV'
  field_delimiter = ','
  skip_header = 1;
  
create table name1(NAME varchar)

create table COVID_GLOBAL1( Country varchar(500),Lat Decimal(8,6),Long Decimal(9,6),Date Date, Confirmed INTEGER, Deaths INTEGER, Recovered INTEGER, Active Integer, WHO_Region Varchar(500));

create pipe demo_db.public.mypipe_covid if not exists as copy into demo_db.public.COVID_GLOBAL from @demo_db.public.global_covid_stage
file_format=mycsvformat;




select * from covid_global1


desc user Varalika13;
alter user Varalika13 set rsa_public_key='MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtaiI9aLTj3rYGd35VAGY
1tPZkodXK87GClx/c6raWkCleo61LS72JPk3xl69le6xnuwYHb/xEE45lzWh7CsT
6i9o6/mACNSCWGjLynPf2JDwdp+jE+rIsjkXzsjJHsjilGs/JvA3kCYc2LRzRAYT
9c81aR8KYClXfMBhQok8pMcW1EGEVcBCii1kQXWwgicj27IE3Heb4rCag7JUf4/i
mwbtMR+pSVR/IMcvyzjBIKYn4xeFCAZFa6BjqavCDlWsulEYOTMwKj9+gRZ/fK2q
y3cLQD5gKYsccFmQ4CDPbHohLbTyX6/6ZirudEUljRxfTaFkLYc7HSVd5+eF8s45
+wIDAQAB';
desc user Varalika13;

 list @snowpipe_stage
select * from covid_global1;